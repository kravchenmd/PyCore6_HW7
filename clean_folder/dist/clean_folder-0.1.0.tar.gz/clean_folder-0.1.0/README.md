# PyCore 6, HW 7: Clean Folder

Readme example to include into the package
